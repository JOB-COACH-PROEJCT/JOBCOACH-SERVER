/*
package org.v1.job_coach.domain.chatroom.dto.response;

public record ConsultingDto(
        private Long id;
        private String feedback;
        private Long answerId;
) {
}
*/
