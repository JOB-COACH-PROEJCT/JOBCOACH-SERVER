package org.v1.job_coach.domain.review.domain;

public enum Evaluation {
    POSITIVE,
    NEUTRAL,
    NEGATIVE
}
