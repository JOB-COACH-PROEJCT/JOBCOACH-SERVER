package org.v1.job_coach.domain.review.domain;

public enum ReviewResult {
    PASS,
    FAIL
}
