package org.v1.job_coach;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobCoachApplicationTests {

    @Test
    void contextLoads() {
    }

}
